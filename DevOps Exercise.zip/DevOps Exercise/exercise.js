var fs = require('fs');
var AWS = require('aws-sdk');
var randomstring = require('randomstring');
var request = require("request")

var url = "https://s3.ap-south-1.amazonaws.com/tania-aws-test/exercise.json"

AWS.config.loadFromPath('credentials.json');

request({
    url: url,
    json: true
	},
	function (error, response, body) {
		if (!error && response.statusCode === 200) {
			var parsedJsonObject = body;
			
			for(var ctr = 0; ctr < parsedJsonObject.cloudfront.length; ctr++) {
				var cloudfront = new AWS.CloudFront();
				
				var invalidationJsonString = '';
				var invalidationParameters = {};
				
				if ('tags' in parsedJsonObject.cloudfront[ctr]) {
					var concatenatedPaths = '';

					for(var ctr2 = 0; ctr2 < parsedJsonObject.cloudfront[ctr].tags.length; ctr2++) {
						if (parsedJsonObject.cloudfront[ctr].tags[ctr2] === 'reset') {
							invalidationJsonString = '{"DistributionId":"' + parsedJsonObject.cloudfront[ctr].id + '","InvalidationBatch":{"CallerReference":"' + randomstring.generate(16) + '","Paths":{"Quantity":"1","Items":["/*"]}}}';
							
							invalidationParameters = JSON.parse(invalidationJsonString);
							
							//console.log(invalidationParameters);
							cloudfront.createInvalidation(invalidationParameters, function(err, data) {
								var requested = invalidationParameters.DistributionId;
								if (err) {
									console.log(requested, err);
								}
								else {
									console.log(data);
								}
							});
						}
					}
				}
			}
		}
	}
);
